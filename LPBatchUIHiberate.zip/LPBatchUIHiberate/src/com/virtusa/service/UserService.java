package com.virtusa.service;

import com.virtusa.model.UserLogin;

public interface UserService {

	boolean userAuthenticationService(UserLogin userModel);
	
}
